#!/bin/bash
set -e
cd /home/site/wwwroot
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
fi
if [ -f alembic.ini ]; then
  alembic upgrade head || true
fi
exec gunicorn -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:8000 --workers 2 --timeout 180
